import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime

DATA_FILE = 'fuel_expenses.csv'

try:
    df = pd.read_csv(DATA_FILE)
except FileNotFoundError:
    df = pd.DataFrame(columns=['Date', 'Vehicle', 'Fuel Type', 'Amount (liters)', 'Price per liter', 'Total Cost'])
    df.to_csv(DATA_FILE, index=False)


def add_entry():
    global df
    date = datetime.now().strftime('%Y-%m-%d')
    vehicle = vehicle_entry.get()
    fuel_type = fuel_type_entry.get()
    amount = amount_entry.get()
    price_per_liter = price_per_liter_entry.get()
    total_cost = float(amount) * float(price_per_liter)

    new_entry = pd.DataFrame([[date, vehicle, fuel_type, amount, price_per_liter, total_cost]],
                             columns=['Date', 'Vehicle', 'Fuel Type', 'Amount (liters)', 'Price per liter',
                                      'Total Cost'])
    df = pd.concat([df, new_entry], ignore_index=True)
    df.to_csv(DATA_FILE, index=False)
    messagebox.showinfo("Успіх", "Запис успішно додано.")
    refresh_display()


def show_graph():
    fuel_type_consumption = df.groupby('Fuel Type')['Amount (liters)'].sum()

    plt.figure(figsize=(8, 6))
    plt.bar(fuel_type_consumption.index, fuel_type_consumption.values, color='skyblue')
    plt.xlabel('Тип пального')
    plt.ylabel('Загальна кількість пального (л)')
    plt.title('Загальна кількість пального за типом')
    plt.xticks(rotation=45)
    plt.show()


def search_entry():
    vehicle = vehicle_search_entry.get()
    fuel_type = fuel_type_search_entry.get()
    search_result = df[(df['Vehicle'] == vehicle) & (df['Fuel Type'] == fuel_type)]
    search_result_window = tk.Toplevel(root)
    search_result_window.title("Результат пошуку")
    tree = ttk.Treeview(search_result_window)
    tree["columns"] = ("Date", "Vehicle", "Fuel Type", "Amount (liters)", "Price per liter", "Total Cost")
    tree.heading('#0', text='Індекс')
    tree.heading('Date', text='Дата')
    tree.heading('Vehicle', text='Транспортний засіб')
    tree.heading('Fuel Type', text='Тип пального')
    tree.heading('Amount (liters)', text='Кількість (л)')
    tree.heading('Price per liter', text='Ціна за літр')
    tree.heading('Total Cost', text='Загальна вартість')
    for index, row in search_result.iterrows():
        tree.insert("", tk.END, text=index, values=row.tolist())
    tree.pack()


def edit_entry():
    selected_item = treeview.focus()
    if selected_item:
        index = int(treeview.item(selected_item, "text"))
        vehicle = vehicle_edit_entry.get()
        fuel_type = fuel_type_edit_entry.get()
        amount = amount_edit_entry.get()
        price_per_liter = price_per_liter_edit_entry.get()
        total_cost = float(amount) * float(price_per_liter)

        df.at[index, 'Vehicle'] = vehicle
        df.at[index, 'Fuel Type'] = fuel_type
        df.at[index, 'Amount (liters)'] = amount
        df.at[index, 'Price per liter'] = price_per_liter
        df.at[index, 'Total Cost'] = total_cost

        df.to_csv(DATA_FILE, index=False)
        messagebox.showinfo("Успіх", "Запис успішно відредаговано.")
        refresh_display()
    else:
        messagebox.showwarning("Помилка", "Редагування не вибрано")


root = tk.Tk()
root.title("Система обліку витрат пального")

tk.Label(root, text="Новий запис").grid(row=0, column=0, columnspan=2)
tk.Label(root, text="Транспортний засіб:").grid(row=1, column=0)
vehicle_entry = tk.Entry(root)
vehicle_entry.grid(row=1, column=1)
tk.Label(root, text="Тип пального:").grid(row=2, column=0)
fuel_type_entry = tk.Entry(root)
fuel_type_entry.grid(row=2, column=1)
tk.Label(root, text="Кількість (л):").grid(row=3, column=0)
amount_entry = tk.Entry(root)
amount_entry.grid(row=3, column=1)
tk.Label(root, text="Ціна за літр:").grid(row=4, column=0)
price_per_liter_entry = tk.Entry(root)
price_per_liter_entry.grid(row=4, column=1)
add_button = tk.Button(root, text="Додати запис", command=add_entry)
add_button.grid(row=5, column=0, columnspan=2)

show_graph_button = tk.Button(root, text="Показати графік", command=show_graph)
show_graph_button.grid(row=6, column=0, columnspan=2)

tk.Label(root, text="Пошук запису").grid(row=7, column=0, columnspan=2)
tk.Label(root, text="Транспортний засіб:").grid(row=8, column=0)
vehicle_search_entry = tk.Entry(root)
vehicle_search_entry.grid(row=8, column=1)
tk.Label(root, text="Тип пального:").grid(row=9, column=0)
fuel_type_search_entry = tk.Entry(root)
fuel_type_search_entry.grid(row=9, column=1)
search_button = tk.Button(root, text="Знайти запис", command=search_entry)
search_button.grid(row=10, column=0, columnspan=2)

tk.Label(root, text="Редагування запису").grid(row=11, column=0, columnspan=2)
tk.Label(root, text="Індекс:").grid(row=12, column=0)
index_edit_entry = tk.Entry(root)
index_edit_entry.grid(row=12, column=1)
tk.Label(root, text="Транспортний засіб:").grid(row=13, column=0)
vehicle_edit_entry = tk.Entry(root)
vehicle_edit_entry.grid(row=13, column=1)
tk.Label(root, text="Тип пального:").grid(row=14, column=0)
fuel_type_edit_entry = tk.Entry(root)
fuel_type_edit_entry.grid(row=14, column=1)
tk.Label(root, text="Кількість (л):").grid(row=15, column=0)
amount_edit_entry = tk.Entry(root)
amount_edit_entry.grid(row=15, column=1)
tk.Label(root, text="Ціна за літр:").grid(row=16, column=0)
price_per_liter_edit_entry = tk.Entry(root)
price_per_liter_edit_entry.grid(row=16, column=1)
edit_button = tk.Button(root, text="Редагувати запис", command=edit_entry)
edit_button.grid(row=17, column=0, columnspan=2)


def refresh_display():
    global treeview
    for i in treeview.get_children():
        treeview.delete(i)
    for index, row in df.iterrows():
        treeview.insert("", "end", text=index, values=row.tolist())


def on_select(event):
    selected_item = treeview.selection()[0]
    index = int(treeview.item(selected_item, "text"))
    entry = df.loc[index]
    vehicle_edit_entry.delete(0, tk.END)
    fuel_type_edit_entry.delete(0, tk.END)
    amount_edit_entry.delete(0, tk.END)
    price_per_liter_edit_entry.delete(0, tk.END)
    vehicle_edit_entry.insert(0, entry['Vehicle'])
    fuel_type_edit_entry.insert(0, entry['Fuel Type'])
    amount_edit_entry.insert(0, entry['Amount (liters)'])
    price_per_liter_edit_entry.insert(0, entry['Price per liter'])


tk.Label(root, text="Дані").grid(row=0, column=2, columnspan=4)
treeview = ttk.Treeview(root,
                        columns=('Date', 'Vehicle', 'Fuel Type', 'Amount (liters)', 'Price per liter', 'Total Cost'))
treeview.heading('#0', text='Індекс')
treeview.heading('Date', text='Дата')
treeview.heading('Vehicle', text='Транспортний засіб')
treeview.heading('Fuel Type', text='Тип пального')
treeview.heading('Amount (liters)', text='Кількість (л)')
treeview.heading('Price per liter', text='Ціна за літр')
treeview.heading('Total Cost', text='Загальна вартість')
treeview.grid(row=1, column=2, rowspan=15, columnspan=4)

treeview.bind("<<TreeviewSelect>>", on_select)
refresh_display()

root.mainloop()
